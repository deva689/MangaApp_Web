import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:manga/screens/detail_summary_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'audio_player_page.dart';

class BookDetailPage extends StatefulWidget {
  final Map<String, dynamic> story;

  const BookDetailPage({super.key, required this.story});

  @override
  State<BookDetailPage> createState() => _BookDetailPageState();
}

class _BookDetailPageState extends State<BookDetailPage> {
  final SupabaseClient supabase = Supabase.instance.client;
  bool isFavorite = false;
  Duration audioDuration = Duration.zero;
  String truncateText(String text, {int limit = 140}) {
    if (text.length <= limit) return text;
    return text.substring(0, limit) + "...";
  }

  @override
  void initState() {
    super.initState();
    _checkFavorite();
    _loadAudioDuration(); // ✅ Fetch duration
    _loadReviewCount();
    _updateStoryRating();
  }

  Future<void> _updateStoryRating() async {
    final supabase = Supabase.instance.client;

    try {
      // fetch all ratings for this story
      final reviews = await supabase
          .from("story_reviews")
          .select("rating")
          .eq("story_id", widget.story["id"].toString());

      double total = 0;
      for (var r in reviews) {
        total += (r["rating"] as num).toDouble();
      }

      int reviewCount = reviews.length;
      double avg = reviewCount == 0 ? 0.0 : total / reviewCount;

      // update stories table
      await supabase
          .from("stories")
          .update({"rating": avg, "total_reviews": reviewCount})
          .eq("id", widget.story["id"].toString());

      if (mounted) {
        setState(() {
          widget.story["rating"] = avg;
          widget.story["total_reviews"] = reviewCount;
        });
      }
    } catch (e) {
      debugPrint("Rating update error: $e");
    }
  }

  Future<void> _loadReviewCount() async {
    final supabase = Supabase.instance.client;

    try {
      final reviews = await supabase
          .from("story_reviews")
          .select("id")
          .eq("story_id", widget.story["id"].toString()); // ✅ widget.story

      if (mounted) {
        setState(() {
          widget.story["rating_count"] = reviews.length; // ✅ update story map
        });
      }
    } catch (e) {
      debugPrint("Load review count error: $e");
    }
  }

  Future<void> _loadAudioDuration() async {
    try {
      final player = AudioPlayer();

      // listen duration stream
      player.onDurationChanged.listen((d) {
        if (mounted) {
          setState(() => audioDuration = d);
        }
        player.dispose();
      });

      await player.setSourceUrl(widget.story['audio_url']);
    } catch (e) {
      debugPrint("Error loading audio duration: $e");
    }
  }

  String _format(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return "${d.inMinutes}:${two(d.inSeconds % 60)}";
  }

  Future<void> _checkFavorite() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      final storyId = widget.story['id']?.toString();

      if (userId == null || storyId == null) return;

      final pref = await supabase
          .from("user_preferences")
          .select("favourites")
          .eq("user_id", userId)
          .maybeSingle();

      if (pref == null) return;

      final favs = List<String>.from(pref["favourites"] ?? []);
      setState(() => isFavorite = favs.contains(storyId));
    } catch (e) {
      debugPrint("Fav check error: $e");
    }
  }

  Future<void> _toggleFavorite() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      final storyId = widget.story['id']?.toString();

      if (userId == null || storyId == null) return;

      final pref = await supabase
          .from("user_preferences")
          .select("favourites")
          .eq("user_id", userId)
          .maybeSingle();

      List<String> favs = [];

      if (pref == null) {
        await supabase.from("user_preferences").insert({
          "user_id": userId,
          "favourites": [storyId],
        });
        setState(() => isFavorite = true);
        return;
      }

      favs = List<String>.from(pref["favourites"] ?? []);

      if (favs.contains(storyId)) {
        favs.remove(storyId);
      } else {
        favs.add(storyId);
      }

      await supabase
          .from("user_preferences")
          .update({"favourites": favs})
          .eq("user_id", userId);

      setState(() => isFavorite = !isFavorite);
    } catch (e) {
      debugPrint("Fav toggle error: $e");
    }
  }

  String _formatRating(dynamic r) {
    if (r == null) return "0.0";
    if (r is num) return r.toStringAsFixed(1);
    return double.tryParse(r.toString())?.toStringAsFixed(1) ?? "0.0";
  }

  @override
  Widget build(BuildContext context) {
    final story = widget.story;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ✅ Top nav bar
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, size: 24),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Row(
                    children: const [
                      Icon(Icons.search, size: 22),
                      SizedBox(width: 18),
                      Icon(Icons.send_outlined, size: 22),
                      SizedBox(width: 18),
                      Icon(Icons.more_vert, size: 22),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 10),

              // ✅ Book preview row
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: CachedNetworkImage(
                      imageUrl: story["image_url"],
                      width: 135,
                      height: 170,
                      fit: BoxFit.cover,
                    ),
                  ),

                  const SizedBox(width: 14),

                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          story["genre"] ?? "",
                          style: TextStyle(
                            color: Colors.orange.shade700,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),

                        const SizedBox(height: 6),

                        Text(
                          story["title"] ?? "",
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            height: 1.2,
                          ),
                        ),

                        const SizedBox(height: 4),

                        Text(
                          story["author"] ?? "",
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade600,
                          ),
                        ),

                        const SizedBox(height: 10),

                        // ✅ Offer banner
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE97A54),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            "Special offer get 50% off",
                            style: TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),

                        const SizedBox(height: 10),

                        // ✅ Listen $10 + price
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        AudioPlayerPage(story: story),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFF3F3F3),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 22,
                                  vertical: 12,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text(
                                "Listen \$${story['price']}",
                                style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),

                            const SizedBox(width: 10),

                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "List Price",
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "\$399",
                                      style: TextStyle(
                                        fontSize: 13,
                                        decoration: TextDecoration.lineThrough,
                                        color: Colors.grey.shade500,
                                      ),
                                    ),

                                    const SizedBox(width: 15),

                                    GestureDetector(
                                      onTap: _toggleFavorite,
                                      child: Icon(
                                        isFavorite
                                            ? Icons.favorite
                                            : Icons.favorite_border,
                                        size: 28,
                                        color: isFavorite
                                            ? Colors.red
                                            : Colors.black87,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 22),

              // ✅ Rating / Pages / Duration Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _infoTile(
                    Icons.star,
                    _formatRating(
                      story['rating'],
                    ), // ✅ shows 3.0 instead of 3 or 0
                    "${story['total_reviews'] ?? 0} reviews",
                  ),

                  _divider(),

                  _infoTile(
                    Icons.timer_outlined,
                    audioDuration.inSeconds == 0
                        ? "Loading..."
                        : _format(audioDuration),
                    "duration",
                  ),
                ],
              ),

              const SizedBox(height: 22),

              // ✅ Book Summary title
              const Text(
                "Book Summary",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),

              const SizedBox(height: 8),

              Text(
                truncateText(story["description"] ?? ""),
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade700,
                  height: 1.4,
                ),
              ),

              const SizedBox(height: 8),

              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DetailSummaryPage(story: story),
                    ),
                  ).then((_) {
                    _loadReviewCount();
                    _updateStoryRating(); // ✅ also refresh rating after return
                  });
                },
                child: Center(
                  child: RichText(
                    text: TextSpan(
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.redAccent,
                        fontWeight: FontWeight.bold,
                      ),
                      children: [
                        TextSpan(text: "READ MORE "),
                        WidgetSpan(
                          child: Icon(
                            Icons.arrow_forward,
                            size: 16,
                            color: Colors.redAccent,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 22),

              // ✅ Chapters title
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    "Available Chapters",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  Icon(Icons.graphic_eq, size: 22),
                ],
              ),

              const SizedBox(height: 10),

              _chapterTile(context, story["title"] ?? "", "3 minutes"),
            ],
          ),
        ),
      ),
    );
  }

  // ✅ Divider inline
  Widget _divider() =>
      Container(height: 30, width: 1.4, color: Colors.grey.shade400);

  // ✅ Chapter Row
  Widget _chapterTile(BuildContext context, String title, String duration) {
    final story = widget.story;

    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
      subtitle: Text(
        duration,
        style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
      ),
      trailing: const Icon(
        Icons.play_circle_fill,
        size: 36,
        color: Colors.black87,
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => AudioPlayerPage(story: story)),
        );
      },
    );
  }

  // ✅ Info Tile (rating/pages/duration)
  Widget _infoTile(IconData icon, String top, String bottom) {
    return Column(
      children: [
        Row(
          children: [
            Text(
              top,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(width: 4),
            Icon(icon, size: 17),
          ],
        ),
        Text(
          bottom,
          style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600),
        ),
      ],
    );
  }
}
