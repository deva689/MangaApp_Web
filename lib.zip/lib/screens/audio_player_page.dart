import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AudioPlayerPage extends StatefulWidget {
  final Map<String, dynamic> story;

  const AudioPlayerPage({super.key, required this.story});

  @override
  State<AudioPlayerPage> createState() => _AudioPlayerPageState();
}

class _AudioPlayerPageState extends State<AudioPlayerPage> {
  final AudioPlayer _player = AudioPlayer();
  late final SupabaseClient supabase;

  bool isPlaying = false;
  bool isLoading = false;
  Duration duration = Duration.zero;
  Duration position = Duration.zero;
  double speed = 1.0;
  bool isFavorite = false;
  bool isLoopEnabled = false;
  bool hasIncreasedViews = false; // ✅ Prevent duplicate view counting

  @override
  void initState() {
    super.initState();
    supabase = Supabase.instance.client;
    _initPlayer();
    _checkFavorite();
  }

  Future<void> _initPlayer() async {
    try {
      _player.setReleaseMode(ReleaseMode.stop);

      _player.onDurationChanged.listen((d) {
        if (mounted) setState(() => duration = d);
      });

      _player.onPositionChanged.listen((p) {
        if (mounted) setState(() => position = p);
      });

      _player.onPlayerComplete.listen((event) {
        if (!mounted) return;
        setState(() {
          isPlaying = false;
          position = Duration.zero;
        });
      });

      // ✅ Auto-play on screen open
      final audioUrl = widget.story['audio_url'];

      if (audioUrl != null && audioUrl.isNotEmpty) {
        setState(() => isLoading = true);

        await _player.setSourceUrl(audioUrl);
        await _player.resume();

        setState(() {
          isPlaying = true;
          isLoading = false;
        });

        _increaseViews(); // ✅ Count view on auto-play
      }
    } catch (e) {
      debugPrint('Error initializing player: $e');
      if (mounted) {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> _increaseViews() async {
    if (hasIncreasedViews) return; // ✅ Prevent duplicate counting

    final storyId = widget.story['id'];
    if (storyId == null) return;

    try {
      final currentViews = widget.story['views'] ?? 0;
      await supabase
          .from('stories')
          .update({'views': currentViews + 1})
          .eq('id', storyId);

      hasIncreasedViews = true; // ✅ Mark as counted
    } catch (e) {
      debugPrint('Error increasing views: $e');
    }
  }

  String _format(Duration d) =>
      "${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}";

  /// Check if story is in favorites
  Future<void> _checkFavorite() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      final storyId = widget.story['id']?.toString();

      if (userId == null || storyId == null) return;

      final pref = await supabase
          .from("user_preferences")
          .select("favourites")
          .eq("user_id", userId)
          .maybeSingle();

      if (pref == null) return;

      final favs = List<String>.from(pref["favourites"] ?? []);

      if (mounted) {
        setState(() => isFavorite = favs.contains(storyId));
      }
    } catch (e) {
      debugPrint("Error checking favorite: $e");
    }
  }

  /// Toggle favorite status
  Future<void> _toggleFavorite() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      final storyId = widget.story['id']?.toString();

      if (userId == null || storyId == null) return;

      final pref = await supabase
          .from("user_preferences")
          .select("favourites")
          .eq("user_id", userId)
          .maybeSingle();

      List<String> favs = [];

      if (pref == null) {
        /// ✅ First-time insert
        await supabase.from("user_preferences").insert({
          "user_id": userId,
          "favourites": [storyId],
        });

        if (mounted) {
          setState(() => isFavorite = true);
        }
        return;
      }

      /// ✅ Get existing favourites
      favs = List<String>.from(pref["favourites"] ?? []);

      /// ✅ Add / Remove favorite
      if (favs.contains(storyId)) {
        favs.remove(storyId);
      } else {
        favs.add(storyId);
      }

      /// ✅ Update Supabase array
      await supabase
          .from("user_preferences")
          .update({"favourites": favs})
          .eq("user_id", userId);

      if (mounted) {
        setState(() => isFavorite = !isFavorite);
      }
    } catch (e) {
      debugPrint("Error toggling favorite: $e");

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to update favorite")),
        );
      }
    }
  }

  /// Toggle playback speed
  void _toggleSpeed() {
    setState(() {
      if (speed == 1.0) {
        speed = 1.5;
      } else if (speed == 1.5) {
        speed = 2.0;
      } else {
        speed = 1.0;
      }
    });
    _player.setPlaybackRate(speed);
  }

  /// Toggle loop mode
  void _toggleLoop() {
    setState(() {
      isLoopEnabled = !isLoopEnabled;
      _player.setReleaseMode(
        isLoopEnabled ? ReleaseMode.loop : ReleaseMode.stop,
      );
    });
  }

  /// Handle play/pause
  Future<void> _togglePlayPause() async {
    try {
      setState(() => isLoading = true);

      if (!isPlaying) {
        final audioUrl = widget.story['audio_url'];
        if (audioUrl == null || audioUrl.isEmpty) {
          throw Exception('Audio URL is missing');
        }

        // ✅ Only set source if not already loaded
        final currentSource = await _player.getCurrentPosition();
        if (currentSource == null || currentSource == Duration.zero) {
          await _player.setSourceUrl(audioUrl);
        }

        await _player.resume();

        // ✅ Only increase views once per session
        if (!hasIncreasedViews) {
          _increaseViews();
        }
      } else {
        await _player.pause();
      }

      setState(() {
        isPlaying = !isPlaying;
        isLoading = false;
      });
    } catch (e) {
      debugPrint('Error toggling play/pause: $e');
      if (mounted) {
        setState(() => isLoading = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Playback error: $e')));
      }
    }
  }

  /// Seek backward 30 seconds
  Future<void> _seekBackward() async {
    final newPosition = position - const Duration(seconds: 30);
    await _player.seek(newPosition.isNegative ? Duration.zero : newPosition);
  }

  /// Seek forward 30 seconds
  Future<void> _seekForward() async {
    final newPosition = position + const Duration(seconds: 30);
    await _player.seek(newPosition > duration ? duration : newPosition);
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final story = widget.story;
    final imageUrl = story['image_url'] ?? '';
    final title = story['title'] ?? 'Untitled';
    final author = story['author'] ?? 'Unknown';
    final genre = story['genre'] ?? 'Story';

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Background image with blur
          if (imageUrl.isNotEmpty)
            Positioned.fill(
              child: Opacity(
                opacity: 0.15,
                child: CachedNetworkImage(
                  imageUrl: imageUrl,
                  fit: BoxFit.cover,
                  placeholder: (context, url) =>
                      Container(color: Colors.grey[900]),
                  errorWidget: (context, url, error) =>
                      Container(color: Colors.grey[900]),
                ),
              ),
            ),

          // Dark overlay
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.6)),
          ),

          // Content
          SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          size: 28,
                          color: Colors.white,
                        ),
                        onPressed: () => Navigator.pop(context),
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_vert, color: Colors.white),
                        onPressed: () {
                          // Add more options menu
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Genre label
                Text(
                  genre,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                    letterSpacing: 1.2,
                  ),
                ),

                const SizedBox(height: 20),

                // Cover image
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CachedNetworkImage(
                    imageUrl: imageUrl,
                    width: 240,
                    height: 300,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      width: 240,
                      height: 300,
                      color: Colors.grey[800],
                      child: const Center(child: CircularProgressIndicator()),
                    ),
                    errorWidget: (context, url, error) => Container(
                      width: 240,
                      height: 300,
                      color: Colors.grey[800],
                      child: const Icon(
                        Icons.music_note,
                        size: 80,
                        color: Colors.white30,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 30),

                // Title
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),

                const SizedBox(height: 8),

                // Author
                Text(
                  author,
                  style: const TextStyle(color: Colors.white60, fontSize: 14),
                ),

                const SizedBox(height: 24),

                // Action buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(
                        isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: isFavorite ? Colors.redAccent : Colors.white,
                        size: 26,
                      ),
                      onPressed: _toggleFavorite,
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      icon: const Icon(
                        Icons.graphic_eq,
                        color: Colors.white,
                        size: 26,
                      ),
                      onPressed: () {
                        // Add equalizer functionality
                      },
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      icon: const Icon(
                        Icons.playlist_add,
                        color: Colors.white,
                        size: 26,
                      ),
                      onPressed: () {
                        // Add to playlist functionality
                      },
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      icon: const Icon(
                        Icons.share,
                        color: Colors.white,
                        size: 26,
                      ),
                      onPressed: () {
                        // Add share functionality
                      },
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // Progress slider
                Slider(
                  value: position.inSeconds.toDouble(),
                  max: duration.inSeconds.toDouble() > 0
                      ? duration.inSeconds.toDouble()
                      : 1,
                  activeColor: Colors.white,
                  inactiveColor: Colors.white30,
                  onChanged: (v) async {
                    await _player.seek(Duration(seconds: v.toInt()));
                  },
                ),

                // Time labels
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _format(position),
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        _format(duration),
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Playback controls
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Speed control
                    TextButton(
                      onPressed: _toggleSpeed,
                      child: Text(
                        "${speed}x",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Rewind 30s
                    IconButton(
                      icon: const Icon(
                        Icons.replay_30_outlined,
                        color: Colors.white,
                      ),
                      iconSize: 36,
                      onPressed: _seekBackward,
                    ),

                    const SizedBox(width: 8),

                    // Play/Pause button
                    GestureDetector(
                      onTap: _togglePlayPause,
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        child: isLoading
                            ? const Padding(
                                padding: EdgeInsets.all(20),
                                child: CircularProgressIndicator(
                                  color: Colors.black,
                                  strokeWidth: 3,
                                ),
                              )
                            : Icon(
                                isPlaying ? Icons.pause : Icons.play_arrow,
                                size: 44,
                                color: Colors.black,
                              ),
                      ),
                    ),

                    const SizedBox(width: 8),

                    // Forward 30s
                    IconButton(
                      icon: const Icon(
                        Icons.forward_30_outlined,
                        color: Colors.white,
                      ),
                      iconSize: 36,
                      onPressed: _seekForward,
                    ),

                    const SizedBox(width: 12),

                    // Loop button
                    IconButton(
                      icon: Icon(
                        Icons.loop,
                        color: isLoopEnabled ? Colors.blueAccent : Colors.white,
                      ),
                      iconSize: 26,
                      onPressed: _toggleLoop,
                    ),
                  ],
                ),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
